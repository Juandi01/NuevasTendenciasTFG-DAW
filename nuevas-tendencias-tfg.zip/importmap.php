<?php

/**
 * Returns the importmap for this application.
 *
 * - "path" is a path inside the asset mapper system. Use the
 *     "debug:asset-map" command to see the full list of paths.
 *
 * - "entrypoint" (JavaScript only) set to true for any module that will
 *     be used as an "entrypoint" (and passed to the importmap() Twig function).
 *
 * The "importmap:require" command can be used to add new entries to this file.
 */
return [
    'app' => [
        'path' => './assets/app.js',
        'entrypoint' => true,
    ],
    'admin' => [
        'path' => './assets/admin.js',
        'entrypoint' => true,
    ],
    '@hotwired/stimulus' => [
        'version' => '3.2.2',
    ],
    '@symfony/stimulus-bundle' => [
        'path' => './vendor/symfony/stimulus-bundle/assets/dist/loader.js',
    ],
    '@hotwired/turbo' => [
        'version' => '7.3.0',
    ],
    'tailwindcss' => [
        'version' => '4.2.2',
    ],
    'tailwindcss/index.min.css' => [
        'version' => '4.2.2',
        'type' => 'css',
    ],
    'three' => [
        'version' => '0.184.0',
    ],
    'three/addons/loaders/GLTFLoader.js' => [
        'version' => '0.184.0',
    ],
    'three/addons/controls/OrbitControls.js' => [
        'version' => '0.184.0',
    ],
    'three/addons/geometries/RoundedBoxGeometry.js' => [
        'version' => '0.184.0',
    ],
];
